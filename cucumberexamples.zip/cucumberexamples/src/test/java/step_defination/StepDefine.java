package step_defination;

public class StepDefine {
	
//	@Given("^User is on Landing page$")
//	public void userIsOnLandingPage() {
//		System.out.println("User is on Landing Page");
//	}
//	
//	@When("^User do login with userid and password$")
//	public void userDoLogin() {
//		System.out.println("User DoLogin");
//	}
//	@Then("^Move to the DashBoard Screen$")
//	public void moveToTheDashBoardScreen() {
//		System.out.println("User Move to DashBoard");
//	}
}
