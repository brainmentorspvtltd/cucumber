package step_defination;

import org.junit.runner.RunWith;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
public class MyStepDefination {




    @Given("^User is on Landing page$")
    public void user_is_on_landing_page() throws Throwable {
        System.out.println("user is on landing page");
    }

    @When("^User do login with userid and password$")
    public void user_do_login_with_userid_and_password() throws Throwable {
        System.out.println("User do Login with userid or password");
    }

    @Then("^Move to the DashBoard Screen$")
    public void move_to_the_dashboard_screen() throws Throwable {
        System.out.println("User move to the next page");
    }

    @And("^Welcome Message Appear$")
    public void welcome_message_appear() throws Throwable {
    	System.out.println("Welcome Message Appear");
    }


}
