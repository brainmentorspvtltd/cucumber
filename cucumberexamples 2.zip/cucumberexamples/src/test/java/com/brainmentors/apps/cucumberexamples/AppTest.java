package com.brainmentors.apps.cucumberexamples;



/**
 * Unit test for simple App.
 */
public class AppTest 
{
   
}
