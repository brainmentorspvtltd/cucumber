package step_defination;



import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.runner.RunWith;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;



@RunWith(Cucumber.class)
public class MyStepDefination {

	


    @Given("^User is on Landing page$")
    public void user_is_on_landing_page() throws Throwable {
        System.out.println("user is on landing page");
    }
    
   
    
   
    @When("^User do register with user details$")
    public void user_do_register_with_user_details(DataTable dataTable) throws Throwable {
    	//List<String> row = dataTable.asList();
    	
    	List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
    	System.out.println("List is "+list);
//    	String name = list.get(0).get("uname");
//    	String city = list.get(0).get("city");
//    	int phone = Integer.parseInt(list.get(0).get("phone"));
//    	String companyName = list.get(0).get("company");
    	
    	for(Map<String , String> record : list) {
    		String name = record.get("uname");
        	String city = record.get("city");
        	int phone = Integer.parseInt(record.get("phone"));
        	String companyName = record.get("company");
        	System.out.println(name+ city  + phone + companyName);
    	}
    	
//    	String name = row.get(0);
//    	String city = row.get(1);
//    	String phone = row.get(2);
//    	String companyName = row.get(3);
    	
    	//List<List<String>> table = dataTable.asLists();
        //throw new PendingException();
    }
    
//    @When("^User do login with \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void user_do_login_with_something_and_something(String userid, String password) throws Throwable {
//       // throw new PendingException();
//    	System.out.println("userid "+userid +" Password "+password);
//    }

//    @When("^User do login with userid and password$")
//    public void user_do_login_with_userid_and_password() throws Throwable {
//        System.out.println("User do Login with userid or password");
//    }

    @Then("^Move to the DashBoard Screen$")
    public void move_to_the_dashboard_screen() throws Throwable {
        System.out.println("User move to the next page");
    }

    @And("^Welcome Message \"([^\"]*)\"$")
    public void welcome_message_something(String message) throws Throwable {
    	// Calling Some API, Web , Mobile
    	String msg = "hello";
        Assert.assertTrue(message.equalsIgnoreCase(msg));
    }


}
