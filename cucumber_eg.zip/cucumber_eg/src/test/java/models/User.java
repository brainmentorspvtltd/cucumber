package models;

public class User {
	private String name;
	private String city;
	private String phone;
	private String company;
	public User(String name, String city, String phone, String company) {
		super();
		this.name = name;
		this.city = city;
		this.phone = phone;
		this.company = company;
	}
	
	@Override
	public String toString() {
		return "User [name=" + name + ", city=" + city + ", phone=" + phone + ", company=" + company + "]";
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
}
