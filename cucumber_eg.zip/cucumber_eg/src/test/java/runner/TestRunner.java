package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;

//import org.testng.annotations.BeforeClass;
//
//import io.cucumber.testng.CucumberOptions;
//import io.cucumber.testng.TestNGCucumberRunner;

//import org.junit.runner.RunWith;
//
//import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;


//@RunWith(Cucumber.class) // Only for Junit
@CucumberOptions(features = "src/test/java/features",
glue = "stepdefinations")
//,stepNotifications = true)
//,stepNotifications = true)
public class TestRunner extends AbstractTestNGCucumberTests {
//	private TestNGCucumberRunner testNGCucumberRunner;
//	@BeforeClass
//	public void setupClass() {
//		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//	}
	
//	public void feature(CucumberFeatureWrapper wrapper) {
//		
//	}
}
