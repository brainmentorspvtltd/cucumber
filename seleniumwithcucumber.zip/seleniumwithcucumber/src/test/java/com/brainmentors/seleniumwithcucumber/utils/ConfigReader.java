package com.brainmentors.seleniumwithcucumber.utils;

import java.util.ResourceBundle;

public interface ConfigReader {
	ResourceBundle rb = ResourceBundle.getBundle("config"); // to read properties file
	public static String getValue(String key) {
		return rb.getString(key);
	}
}
