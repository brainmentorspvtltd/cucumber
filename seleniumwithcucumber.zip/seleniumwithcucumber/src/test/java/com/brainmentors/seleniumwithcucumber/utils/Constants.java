package com.brainmentors.seleniumwithcucumber.utils;

public interface Constants {
	String DRIVER_PATH="driverpath"; // public static final String DRIVER_PATH="driverpath"
	String URL = "url";
}
