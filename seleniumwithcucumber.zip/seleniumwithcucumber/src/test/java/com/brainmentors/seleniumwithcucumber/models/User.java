package com.brainmentors.seleniumwithcucumber.models;

public class User {

}
