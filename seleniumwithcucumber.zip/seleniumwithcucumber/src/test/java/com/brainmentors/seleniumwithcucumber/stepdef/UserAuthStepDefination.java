package com.brainmentors.seleniumwithcucumber.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.brainmentors.seleniumwithcucumber.utils.ConfigReader;
import com.brainmentors.seleniumwithcucumber.utils.Constants;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UserAuthStepDefination {

	WebDriver driver; 
	@Given("^User is on Login Page$")
    public void user_is_on_login_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", ConfigReader.getValue(Constants.DRIVER_PATH));
	       driver = new ChromeDriver();
	       driver.get(ConfigReader.getValue(Constants.URL));
    }
    @When("^User will login with userid \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void user_will_login_with_userid_something_and_password_something(String userid, String pwd) throws Throwable {
    	WebElement email = driver.findElement(By.name("email"));
    	email.sendKeys(userid);
    	WebElement password = driver.findElement(By.name("password"));
    	password.sendKeys(pwd);
       
       
    }

    @Then("^Move to the Home Page$")
    public void move_to_the_home_page() throws Throwable {
        driver.findElement(By.className("btn-lg")).click();
    }

    @And("^Check the Message Wrong$")
    public void check_the_message_login_successfully() throws Throwable {
    	String url = driver.getCurrentUrl();
    	String text = driver.findElement(By.className("alert")).getText();
        Assert.assertTrue(text.contains("Wrong") || url.contains("failed"));
        driver.quit();
    }
}









