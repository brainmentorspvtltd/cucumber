package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import models.User;

public class CSVReader {
	public static ArrayList<User> readCSV() throws IOException {
		String filePath = ConfigReader.getValue(Constants.CSV_FILE_PATH);
        //String filePath = "/Users/amitsrivastava/Documents/cuc-examples-new/cucumber_eg/src/test/resources/users.csv";
        File file = new File(filePath);
        if(!file.exists()) {
            System.out.println("Invalid Path , File Not Exist");
            return null;
        }
        FileInputStream fs = new FileInputStream(file);
        //byte allBytes[] = fs.readAllBytes();
        int singleByte = fs.read();
        final int EOF = -1;
        StringBuilder sb = new StringBuilder();
        while(singleByte!=EOF) {
            sb.append((char)singleByte);
            singleByte = fs.read();
            
        }
        //String allData = new String(allBytes);
        //System.out.println("Data is "+allData);
        String lines[] = sb.toString().split("\n");
        ArrayList<User> users = new ArrayList<>();
        for(String line : lines) {
            User user = new User();
            //System.out.println(line);
            String words[] = line.split(",");
            user.setName(words[0]);
            user.setCity(words[1]);
            user.setPhone(words[2]);
            user.setCompany(words[3]);
            users.add(user);
        }
        return users;
    }
}
