package utils;

public interface Constants {
	String CSV_FILE_PATH = "csvfile";
	String JSON_FILE_PATH = "jsonfile";
	String XLS_FILE_PATH="xlspath";
}
