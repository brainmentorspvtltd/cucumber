package utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import java.util.ResourceBundle;

public interface ConfigReader {
	Properties prop = new Properties();
	 ResourceBundle resourceBundle = ResourceBundle.getBundle("config");
	static String getValue(String key){
		//prop.load(new FileInputStream(""));
		//prop.put("a", "a1");
		//prop.save(new FileOutputStream(arg0), comments);
		return resourceBundle.getString(key);
	}
}
