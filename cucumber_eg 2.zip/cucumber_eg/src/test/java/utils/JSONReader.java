package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;

import models.User;

public class JSONReader {
	public static void main(String[] args) {
			try {
				JSONReader.readJSON();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static List<User> readJSON() throws IOException {
		List<User> users = new ArrayList<>();
		String path = ConfigReader.getValue(Constants.JSON_FILE_PATH);
		File file = new File(path);
		if(!file.exists()) {
			throw new RuntimeException("JSON File Not Exist to Read....");
		}
		FileInputStream fs = new FileInputStream(file);
		//byte allBytes[] = fs.readAllBytes();
		int singleByte = fs.read();
        final int EOF = -1;
        StringBuilder sb = new StringBuilder();
        while(singleByte!=EOF) {
            sb.append((char)singleByte);
            singleByte = fs.read();
            
        }
		//String json = new String(allBytes);
        String json = sb.toString();
		Gson gson = new Gson();
		Map<String,ArrayList<LinkedTreeMap<String,String>>> map = gson.fromJson(json, Map.class);
		ArrayList<LinkedTreeMap<String,String>> list = map.get("users");
		for(LinkedTreeMap<String, String> m : list) {
			String name = m.get("name");
			String city = m.get("city");
			String phone = m.get("phone");
			String company = m.get("company");
			User user = new User(name, city,phone, company);
			users.add(user);
			//System.out.println("Name "+name+" City "+city+" Phone "+phone+" Company "+company);
		}
		
		//System.out.println(map);
		System.out.println("List is "+users);
		return users;
	}

	
	
	
}
