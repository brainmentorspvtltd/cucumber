package stepdefinations;



import java.util.List;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import models.User;
import utils.CSVReader;
import utils.ExcelReader;
import utils.JSONReader;
//import io.cucumber.junit.Cucumber;



//@RunWith(Cucumber.class)
public class MyStepDefination {

	


    @Given("^User is on Landing page$")
    public void user_is_on_landing_page() throws Throwable {
        System.out.println("#####################user is on landing page");
    }
    
   
//    @When("^User do.*")
//    public void matchIt() {
//    	System.out.println("I am Start with WHEN *******************");
//    }
    
//    @BeforeClass   
//    public void before() {
//    	System.out.println("I am Before CLASS#################");
//    }
    @Given("^Verify a Browser$")
    public void verify_a_browser() throws Throwable {
        System.out.println("Verify a Browser");
    }

    @When("^Open a Browser$")
    public void open_a_browser() throws Throwable {
    	System.out.println("Open a Browser");
    }

    @Then("^Check Browser is Running$")
    public void check_browser_is_running() throws Throwable {
    	System.out.println("Check Browser is Running");
    }
    
    
    
    @When("^User Name Pass and Get the User Details (.+)$")
    public void user_name_pass_and_get_the_user_details(String uname) throws Throwable {
       //List<User> users = JSONReader.readJSON();
    	//List<User> users = CSVReader.readCSV();
    	List<User> users = ExcelReader.readXLS(0);
    	System.out.println("user are ::::::::: "+users);
       User userInfo = null;
       for(User user:users) {
    	   if(user.getName().equalsIgnoreCase(uname)) {
    		   userInfo  = user;
    		   break;
    	   }
       }
       System.out.println("user info ######## "+userInfo);
    }
    
//    static int counter =0;
//    @When("^User do register with user details (.+) (.+) (.+) (.+)$")
//    public void user_do_register_with_user_details(String uname, String city, String phone, String company) throws Throwable {
//    	counter++;
//        	System.out.println("COUNT "+counter);
//        	System.out.println(uname + " "+city + " "+phone +" "+company);
//    }
    
  // @When("^User do register with user details$")
   // @Test
    //public void user_do_register_with_user_details(DataTable dataTable) throws Throwable {
    	//List<String> row = dataTable.asList();
//    	
//    	List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
//    	System.out.println("List is "+list);
////    	String name = list.get(0).get("uname");
////    	String city = list.get(0).get("city");
////    	int phone = Integer.parseInt(list.get(0).get("phone"));
////    	String companyName = list.get(0).get("company");
//    	
//    	for(Map<String , String> record : list) {
//    		String name = record.get("uname");
//        	String city = record.get("city");
//        	int phone = Integer.parseInt(record.get("phone"));
//        	String companyName = record.get("company");
//        	System.out.println(name+ city  + phone + companyName);
//    	}
//    	
////    	String name = row.get(0);
////    	String city = row.get(1);
////    	String phone = row.get(2);
////    	String companyName = row.get(3);
//    	
//    	//List<List<String>> table = dataTable.asLists();
//        //throw new PendingException();
//    }
    
//    @When("^User do login with \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void user_do_login_with_something_and_something(String userid, String password) throws Throwable {
//       // throw new PendingException();
//    	System.out.println("userid "+userid +" Password "+password);
//    }

//    @When("^User do login with userid and password$")
//    public void user_do_login_with_userid_and_password() throws Throwable {
//        System.out.println("User do Login with userid or password");
//    }

    @Then("^Move to the DashBoard Screen$")
    public void move_to_the_dashboard_screen() throws Throwable {
        System.out.println("User move to the next page");
    }

    @And("^Welcome Message \"([^\"]*)\"$")
    public void welcome_message_something(String message) throws Throwable {
    	// Calling Some API, Web , Mobile
    	String msg = "hello";
        //Assert.assertTrue(message.equalsIgnoreCase(msg));
    }


}
