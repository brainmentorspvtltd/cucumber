package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class MyHook {
	
	@Before(order = 1)
	public void setup2() {
		// WebDriver Start , DB Connection Start, Test Data Prepare
		//Move to some Page
	}
	
	@Before(order = 0, value="@E2ETest,@SmokeTest")
	public void setup3() {
		// WebDriver Start , DB Connection Start, Test Data Prepare
		//Move to some Page
	}
	
	@Before(value="@SmokeTest",order = 2)
	public void setup() {
		// WebDriver Start , DB Connection Start, Test Data Prepare
		//Move to some Page
	}
	
	@After(order = 1)
	public void tear() {
		// webdriver close, db connection close, clear test data, logout application,
		// logs or report print, error screenshot
	}
}
